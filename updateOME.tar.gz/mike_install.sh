for ((j = 0; j <= 7; j++))

do

  if [ $j == 0 ]; then 
      cur_file='Home.pm'
      cur_dir='./src/perl2/OME/Web/'
  fi

  if [ $j == 1 ]; then 
      cur_file='ImageMetadata.pm'
      cur_dir='./src/perl2/OME/Web/'
  fi

  if [ $j == 2 ]; then
      cur_file='Home.tmpl'
      cur_dir='./src/html/Templates/System/Actions/'
  fi

  if [ $j == 3 ]; then
      cur_file='metadata.tmpl'
      cur_dir='./src/html/Templates/System/Display/One/'
  fi

  if [ $j == 4 ]; then
      cur_file='SearchBox.tmpl'
      cur_dir='./src/html/Templates/System/Actions/'
  fi

  if [ $j == 5 ]; then 
      cur_file='DBObjRender.pm'
      cur_dir='./src/perl2/OME/Web/'
  fi

  if [ $j == 6 ]; then
      cur_file='summary.tmpl'
      cur_dir='./src/html/Templates/System/Display/One/OME/Image/'
  fi

  if [ $j == 7 ]; then
      cur_file='Server.pm'
      cur_dir='./src/perl2/OME/Image/'
  fi

 
  if [ -f $cur_dir$cur_file ]; then
      mv $cur_dir$cur_file $cur_dir$cur_file".bak"
  fi

  cp -p "mike_files"/$cur_file $cur_dir$cur_file

done